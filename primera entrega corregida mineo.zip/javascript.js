let dolarblue = 211;
const dolarbluepeso = 0.0047;
const dolaroficial = 106;
const dolaroficialpeso = 0.0094;


let monto = prompt ('¿cotización del dolar a 106 o a 211?')

function cantidadacobrar ( aCobrar ) {
    let result = aCobrar * monto
    return result
    console.log ( result )
}
let result = cantidadacobrar(prompt ('cuantos dolares'))
console.log (result)

if (monto == 106){
    console.log ('vas a convertir a precio oficial')
    alert ('vas a convertir a precio oficial')
}
else if (monto == 211) {
    console.log ('vas a convertir a precio blue')
    alert ('vas a convertir a precio blue')
}
else {
    alert ("dale, no te hagas el vivo");
    while(monto != 106, 211) {
        monto = prompt ("otra vez, a 106 o a 211?")
        if (monto == 106){
            console.log ('vas a convertir a precio oficial')
            alert ('vas a convertir a precio oficial')
            break
        }
        else if (monto == 211) {
            console.log ('vas a convertir a precio blue')
            alert ('vas a convertir a precio blue')
    }
}
}
