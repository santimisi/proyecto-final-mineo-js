

let url = 'https://api.bluelytics.com.ar/v2/latest'
  fetch (url)
  .then((resp) => resp.json())
  .then((data) => mostrarData (data))
  .catch((error) => console.log (error))

  const mostrarData = (data) => {
    console.log (data)
    localStorage.setItem ("dolarprecios", JSON.stringify ({data}))
  }



let JSONdolarprecios = JSON.parse (localStorage.getItem ("dolarprecios"))
let JSONdolarblue = JSONdolarprecios.data.blue.value_sell;
let JSONdolarbluepeso = 1 / JSONdolarprecios.data.blue.value_sell;
let JSONdolaroficial = JSONdolarprecios.data.oficial.value_sell;
let JSONdolaroficialpeso = 1 / JSONdolarprecios.data.oficial.value_sell;



let entradaInputDBaP = document.getElementById ("areaInputDBaP")
entradaInputDBaP.onkeyup = (eventDBaP) =>{if (eventDBaP.code === 'Enter') { console.log (entradaInputDBaP.value * JSONdolarblue)}}
const botonInputDBaP = document.getElementById ('botonInputDBaP')
botonInputDBaP.onclick = () => {
    console.log ( entradaInputDBaP.value * JSONdolarblue)

    Toastify({
        text: 'Tenes  ' +  entradaInputDBaP.value * JSONdolarblue + ' pesos' ,
        duration: 3000,
        destination: "https://github.com/apvarun/toastify-js",
        newWindow: true,
        close: true,
        gravity: "bottom", // `top` or `bottom`
        position: "right", // `left`, `center` or `right`
        stopOnFocus: true, // Prevents dismissing of toast on hover
        style: {
          background: "linear-gradient(to right, #00b09b, #96c93d)",
        },
        onClick: function(){} // Callback after click
      }).showToast();
}
let resultDBaP = entradaInputDBaP.value

const entradaInputDOaP = document.getElementById ("areaInputDOaP")
entradaInputDOaP.onkeyup = (eventDOaP) =>{if (eventDOaP.code === 'Enter') { console.log (entradaInputDOaP.value * JSONdolaroficial) }}
const botonInputDOaP = document.getElementById ('botonInputDOaP')
botonInputDOaP.onclick = () => {
    console.log ( entradaInputDOaP.value * JSONdolaroficial)

    Toastify({
        text: 'Tenes  ' +  entradaInputDOaP.value * JSONdolaroficial + ' pesos' ,
        duration: 3000,
        destination: "https://github.com/apvarun/toastify-js",
        newWindow: true,
        close: true,
        gravity: "bottom", // `top` or `bottom`
        position: "right", // `left`, `center` or `right`
        stopOnFocus: true, // Prevents dismissing of toast on hover
        style: {
          background: "linear-gradient(to right, #00b09b, #96c93d)",
        },
        onClick: function(){} // Callback after click
      }).showToast();
}
let resultDOaP = entradaInputDOaP.value * JSONdolaroficial





const entradaInputPaDB = document.getElementById ("areaInputPaDB")
entradaInputPaDB.onkeyup = (eventPaDB) =>{if (eventPaDB.code === 'Enter') { console.log (entradaInputPaDB.value * JSONdolarbluepeso) }}
const botonInputPaDB = document.getElementById ('botonInputPaDB')
botonInputPaDB.onclick = () => {
    console.log ( entradaInputPaDB.value * JSONdolarbluepeso)

    Toastify({
        text: 'Tenes  ' +  entradaInputPaDB.value * JSONdolarbluepeso + ' dolares' ,
        duration: 3000,
        destination: "https://github.com/apvarun/toastify-js",
        newWindow: true,
        close: true,
        gravity: "bottom", // `top` or `bottom`
        position: "right", // `left`, `center` or `right`
        stopOnFocus: true, // Prevents dismissing of toast on hover
        style: {
          background: "linear-gradient(to right, #00b09b, #96c93d)",
        },
        onClick: function(){} // Callback after click
      }).showToast();
    
}
let resultPaDB = entradaInputPaDB.value * JSONdolarbluepeso



const entradaInputPaDO = document.getElementById ("areaInputPaDO")
entradaInputPaDO.onkeyup = (eventPaDO) =>{if (eventPaDO.code === 'Enter') { console.log (entradaInputPaDO.value * JSONdolaroficialpeso) }}
const botonInputPaDO = document.getElementById ('botonInputPaDO')
botonInputPaDO.onclick = () => {
    console.log ( entradaInputPaDO.value * JSONdolaroficialpeso)

    Toastify({
        text: 'Tenes  ' +  entradaInputPaDO.value * JSONdolaroficialpeso + ' dolares' ,
        duration: 3000,
        destination: "https://github.com/apvarun/toastify-js",
        newWindow: true,
        close: true,
        gravity: "bottom", // `top` or `bottom`
        position: "right", // `left`, `center` or `right`
        stopOnFocus: true, // Prevents dismissing of toast on hover
        style: {
          background: "linear-gradient(to right, #00b09b, #96c93d)",
        },
        onClick: function(){} // Callback after click
      }).showToast();
}
let resultPaDO = entradaInputPaDO.value * JSONdolaroficialpeso

  
