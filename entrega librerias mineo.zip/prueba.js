    localStorage.setItem ("dolarprecio",
    JSON.stringify ({dolarblue : 211, dolarbluepeso: 0.0047, dolaroficial : 106, dolaroficialpeso : 0.0094})
)

let JSONdolarprecio = JSON.parse (localStorage.getItem ("dolarprecio"))
let JSONdolarblue = JSONdolarprecio.dolarblue;
let JSONdolarbluepeso = JSONdolarprecio.dolarbluepeso;
let JSONdolaroficial = JSONdolarprecio.dolaroficial;
let JSONdolaroficialpeso = JSONdolarprecio.dolaroficialpeso;



let entradaInputDBaP = document.getElementById ("areaInputDBaP")
entradaInputDBaP.onkeyup = (eventDBaP) =>{if (eventDBaP.code === 'Enter') { console.log (entradaInputDBaP.value * JSONdolarblue)}}
const botonInputDBaP = document.getElementById ('botonInputDBaP')
botonInputDBaP.onclick = () => {
    console.log ( entradaInputDBaP.value * JSONdolarblue)

    Toastify({
        text: 'Tenes  ' +  entradaInputDBaP.value * JSONdolarblue + ' pesos' ,
        duration: 3000,
        destination: "https://github.com/apvarun/toastify-js",
        newWindow: true,
        close: true,
        gravity: "bottom", // `top` or `bottom`
        position: "right", // `left`, `center` or `right`
        stopOnFocus: true, // Prevents dismissing of toast on hover
        style: {
          background: "linear-gradient(to right, #00b09b, #96c93d)",
        },
        onClick: function(){} // Callback after click
      }).showToast();
}
let resultDBaP = entradaInputDBaP.value

const entradaInputDOaP = document.getElementById ("areaInputDOaP")
entradaInputDOaP.onkeyup = (eventDOaP) =>{if (eventDOaP.code === 'Enter') { console.log (entradaInputDOaP.value * JSONdolaroficial) }}
const botonInputDOaP = document.getElementById ('botonInputDOaP')
botonInputDOaP.onclick = () => {
    console.log ( entradaInputDOaP.value * JSONdolaroficial)

    Toastify({
        text: 'Tenes  ' +  entradaInputDOaP.value * JSONdolaroficial + ' pesos' ,
        duration: 3000,
        destination: "https://github.com/apvarun/toastify-js",
        newWindow: true,
        close: true,
        gravity: "bottom", // `top` or `bottom`
        position: "right", // `left`, `center` or `right`
        stopOnFocus: true, // Prevents dismissing of toast on hover
        style: {
          background: "linear-gradient(to right, #00b09b, #96c93d)",
        },
        onClick: function(){} // Callback after click
      }).showToast();
}
let resultDOaP = entradaInputDOaP.value * JSONdolaroficial





const entradaInputPaDB = document.getElementById ("areaInputPaDB")
entradaInputPaDB.onkeyup = (eventPaDB) =>{if (eventPaDB.code === 'Enter') { console.log (entradaInputPaDB.value * JSONdolarbluepeso) }}
const botonInputPaDB = document.getElementById ('botonInputPaDB')
botonInputPaDB.onclick = () => {
    console.log ( entradaInputPaDB.value * JSONdolarbluepeso)

    Toastify({
        text: 'Tenes  ' +  entradaInputPaDB.value * JSONdolarbluepeso + ' dolares' ,
        duration: 3000,
        destination: "https://github.com/apvarun/toastify-js",
        newWindow: true,
        close: true,
        gravity: "bottom", // `top` or `bottom`
        position: "right", // `left`, `center` or `right`
        stopOnFocus: true, // Prevents dismissing of toast on hover
        style: {
          background: "linear-gradient(to right, #00b09b, #96c93d)",
        },
        onClick: function(){} // Callback after click
      }).showToast();
    
}
let resultPaDB = entradaInputPaDB.value * JSONdolarbluepeso



const entradaInputPaDO = document.getElementById ("areaInputPaDO")
entradaInputPaDO.onkeyup = (eventPaDO) =>{if (eventPaDO.code === 'Enter') { console.log (entradaInputPaDO.value * JSONdolaroficialpeso) }}
const botonInputPaDO = document.getElementById ('botonInputPaDO')
botonInputPaDO.onclick = () => {
    console.log ( entradaInputPaDO.value * JSONdolaroficialpeso)

    Toastify({
        text: 'Tenes  ' +  entradaInputPaDO.value * JSONdolaroficialpeso + ' dolares' ,
        duration: 3000,
        destination: "https://github.com/apvarun/toastify-js",
        newWindow: true,
        close: true,
        gravity: "bottom", // `top` or `bottom`
        position: "right", // `left`, `center` or `right`
        stopOnFocus: true, // Prevents dismissing of toast on hover
        style: {
          background: "linear-gradient(to right, #00b09b, #96c93d)",
        },
        onClick: function(){} // Callback after click
      }).showToast();
}
let resultPaDO = entradaInputPaDO.value * JSONdolaroficialpeso

