    localStorage.setItem ("dolarprecio",
    JSON.stringify ({dolarblue : 211, dolarbluepeso: 0.0047, dolaroficial : 106, dolaroficialpeso : 0.0094})
)

let JSONdolarprecio = JSON.parse (localStorage.getItem ("dolarprecio"))
let JSONdolarblue = JSONdolarprecio.dolarblue;
let JSONdolarbluepeso = JSONdolarprecio.dolarbluepeso;
let JSONdolaroficial = JSONdolarprecio.dolaroficial;
let JSONdolaroficialpeso = JSONdolarprecio.dolaroficialpeso;



/*
let moneda = prompt ('¿tenes dolares o pesos?')
if (moneda === "dolares") {
    let resultdolar = cantidadacobrardolares(prompt ('cuantos dolares'))
console.log (resultdolar)
cantidadacobrardolares}
else if (moneda === "pesos") {let resultpeso = cantidadacobrarpesos(prompt ('cuantos pesos'))
console.log (resultpeso)
cantidadacobrarpesos}




function cantidadacobrardolares ( aCobrarDolar ) {

    let monto = prompt ('¿cotización del dolar a 106 o a 211?')
    if (monto == dolaroficial){
        console.log ('vas a convertir a precio oficial')
        alert ('vas a convertir a precio oficial')
    }
    else if (monto == dolarblue) {
        console.log ('vas a convertir a precio blue')
        alert ('vas a convertir a precio blue')
    }
    else {
        alert ("dale, no te hagas el vivo");
        while(monto != dolaroficial, dolarblue) {
            monto = prompt ("otra vez, a 106 o a 211?")
            if (monto == dolaroficial){
                console.log ('vas a convertir a precio oficial')
                alert ('vas a convertir a precio oficial')
                break
            }
            else if (monto == dolarblue) {
                console.log ('vas a convertir a precio blue')
                alert ('vas a convertir a precio blue')
        }
    }
    }

    let resultfundolar = aCobrarDolar * monto
    return resultfundolar
}



function cantidadacobrarpesos ( aCobrarPeso ) {

    let monto = prompt ('¿cotización del peso a 0.0047 (blue) o a 0.0094 (oficial)?')
    if (monto == dolaroficialpeso){
        console.log ('vas a convertir a precio oficial')
        alert ('vas a convertir a precio oficial')
    }
    else if (monto == dolarbluepeso) {
        console.log ('vas a convertir a precio blue')
        alert ('vas a convertir a precio blue')
    }
    else {
        alert ("dale, no te hagas el vivo");
        while(monto != dolaroficialpeso, dolarbluepeso) {
            monto = prompt ("otra vez, a 0.0047 (oficial) o a 0.0094 (blue)?")
            if (monto == dolaroficialpeso){
                console.log ('vas a convertir a precio oficial')
                alert ('vas a convertir a precio oficial')
                break
            }
            else if (monto == dolarbluepeso) {
                console.log ('vas a convertir a precio blue')
                alert ('vas a convertir a precio blue')
        }
    }
    }
    let resultfunpeso = aCobrarPeso * monto
    return resultfunpeso
}
*/

let entradaInputDBaP = document.getElementById ("areaInputDBaP")
entradaInputDBaP.onkeyup = (eventDBaP) =>{if (eventDBaP.code === 'Enter') { console.log (entradaInputDBaP.value * JSONdolarblue)}}
const botonInputDBaP = document.getElementById ('botonInputDBaP')
botonInputDBaP.onclick = () => {
    const resultadoimpreso = document.createElement ('p')
    resultadoimpreso.innerText = entradaInputDBaP.value * JSONdolarblue;
    document.body.append (resultadoimpreso)
    console.log ( entradaInputDBaP.value * JSONdolarblue)
}
let resultDBaP = entradaInputDBaP.value

const entradaInputDOaP = document.getElementById ("areaInputDOaP")
entradaInputDOaP.onkeyup = (eventDOaP) =>{if (eventDOaP.code === 'Enter') { console.log (entradaInputDOaP.value * JSONdolaroficial) }}
const botonInputDOaP = document.getElementById ('botonInputDOaP')
botonInputDOaP.onclick = () => {
    console.log ( entradaInputDOaP.value * JSONdolaroficial)

}
let resultDOaP = entradaInputDOaP.value * JSONdolaroficial





const entradaInputPaDB = document.getElementById ("areaInputPaDB")
entradaInputPaDB.onkeyup = (eventPaDB) =>{if (eventPaDB.code === 'Enter') { console.log (entradaInputPaDB.value * JSONdolarbluepeso) }}
const botonInputPaDB = document.getElementById ('botonInputPaDB')
botonInputPaDB.onclick = () => {
    console.log ( entradaInputPaDB.value * JSONdolarbluepeso)
    
}
let resultPaDB = entradaInputPaDB.value * JSONdolarbluepeso



const entradaInputPaDO = document.getElementById ("areaInputPaDO")
entradaInputPaDO.onkeyup = (eventPaDO) =>{if (eventPaDO.code === 'Enter') { console.log (entradaInputPaDO.value * JSONdolaroficialpeso) }}
const botonInputPaDO = document.getElementById ('botonInputPaDO')
botonInputPaDO.onclick = () => {
    console.log ( entradaInputPaDO.value * JSONdolaroficialpeso)
}
let resultPaDO = entradaInputPaDO.value * JSONdolaroficialpeso

